package vo;

// 대분류 정보를 저장할 클래스
public class CataBigInfo {
	private String cb_id, cb_name;

	public String getCb_id() {
		return cb_id;
	}

	public void setCb_id(String cb_id) {
		this.cb_id = cb_id;
	}

	public String getCb_name() {
		return cb_name;
	}

	public void setCb_name(String cb_name) {
		this.cb_name = cb_name;
	} 
	
}
