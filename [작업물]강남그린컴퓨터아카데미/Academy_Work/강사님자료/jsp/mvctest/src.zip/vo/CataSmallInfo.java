package vo;

public class CataSmallInfo {
// �Һз� ������ ������ Ŭ����
	private String cs_id, cb_id, cs_name;

	public String getCs_id() {
		return cs_id;
	}

	public void setCs_id(String cs_id) {
		this.cs_id = cs_id;
	}

	public String getCb_id() {
		return cb_id;
	}

	public void setCb_id(String cb_id) {
		this.cb_id = cb_id;
	}

	public String getCs_name() {
		return cs_name;
	}

	public void setCs_name(String cs_name) {
		this.cs_name = cs_name;
	}
}
