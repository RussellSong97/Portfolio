class Test {
	public static void main(String[] args) {
		test();
	}
	public static void test() {
		System.out.println("Hello World!");
	}
}
