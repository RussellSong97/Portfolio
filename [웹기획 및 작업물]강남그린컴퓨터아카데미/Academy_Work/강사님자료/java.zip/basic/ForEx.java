class ForEx {
	public static void main(String[] args) {
		for (int i = 0 ; i < 3 ; i++) {
			System.out.println("i : " + i);
		}

		int n = 1;
		for (; n <= 5 ; n += 2) {
			System.out.println("n : " + n);
		}

		for (int i = 1 ; i <= 9 ; i++) {
			System.out.println("5 X " + i + " = " + i * 5);
		}
	}
}
